
import React, { Component } from 'react';

import MainForm from '../components/MainForm';

export default class Test extends Component {

  render() {
    return(
      <div className="card main-card pb-3 mb-3">
        <MainForm />  </div>  );
        
  }
}
